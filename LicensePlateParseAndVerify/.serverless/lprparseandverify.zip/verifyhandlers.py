import json
import logging
import os
import boto3
import datetime
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
lpr_table = dynamodb.Table(os.environ['LPR_DYNAMODB_TABLE'])
valet_table = dynamodb.Table(os.environ['VALET_DYNAMODB_TABLE'])
registered_plate_tracker_table = dynamodb.Table(os.environ['REGISTERED_PLATE_TRACKER_TABLE'])
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def getDaysSinceEpoch():
    """Calculates the number of full days since the Unix epoch (1970-01-01) in UTC."""
    # Get the current time as a timezone-aware object in UTC
    current_time_utc = datetime.datetime.now(datetime.timezone.utc)
    
    # Define the Unix epoch as a timezone-aware object in UTC
    epoch_utc = datetime.datetime(1970, 1, 1, tzinfo=datetime.timezone.utc)
    
    # Calculate the difference in days
    days_since_epoch = (current_time_utc - epoch_utc).days
    
    return days_since_epoch

def clean_levenshtein(s1, s2):
    s1 = s1.lower().replace('-', '').replace(' ', '')
    s2 = s2.lower().replace('-', '').replace(' ', '')
    return levenshtein(s1, s2)

def levenshtein(s1, s2):

    if len(s1) < len(s2):
        return levenshtein(s2, s1)

    if len(s2) == 0:
        return len(s1)

    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row

    return previous_row[-1]

def verifylprdata(event, context):
    logger.info(f"Received event: {json.dumps(event)}")

    for record in event['Records']:
        try:
            item_guids = json.loads(record['body'])
            logger.info(f"Processing GUIDs: {item_guids}")

            for guid in item_guids:
                # Query DynamoDB to get the item using the plate_read_id
                response = lpr_table.query(
                    KeyConditionExpression=Key('plate_read_id').eq(guid)
                )

                if response['Items']:
                    # Assuming plate_read_id is unique, so we take the first item
                    item = response['Items'][0]
                    plate_read_id = item.get('plate_read_id')
                    plate_read_timestamp = item.get('plate_read_timestamp')
                    best_confidence = item.get('best_confidence')
                    best_plate_number = item.get('best_plate_number')
                    best_region = item.get('best_region')
                    camera_label = item.get('camera_label')
                    days_since_epoch = item.get('days_since_epoch')
                    plate_crop_jpeg_url = item.get('plate_crop_jpeg_url')
                    vehicle_crop_jpeg_url = item.get('vehicle_crop_jpeg_url')

                    logger.info(f"Verifying plate_read_id: {plate_read_id} plate: {best_plate_number} Location: {camera_label}")

                    if camera_label == '900 Garage Gate Entrance':
                        # logger.info("Plate at Entrance - checking against registered plates.")
                        # Load registered license plates from the file.
                        try:
                            # Assuming the text file is in the same directory as the handler.
                            script_dir = os.path.dirname(__file__)
                            file_path = os.path.join(script_dir, 'Registered_License_Plates.txt')
                            with open(file_path, 'r') as f:
                                registered_plates = [line.strip() for line in f if line.strip()]
                        except FileNotFoundError:
                            logger.error("Registered_License_Plates.txt not found.")
                            return

                        if not best_plate_number:
                            logger.info("No 'best_plate_number' in the item to check.")
                            return

                        # Loop through registered plates and check for a match.
                        is_registered = False
                        for plate in registered_plates:
                            
                            if clean_levenshtein(plate, best_plate_number) <= 1:
                                is_registered = True

                            if is_registered:
                                logger.info(f"MATCH FOUND: Detected plate '{best_plate_number}' matches registered plate '{plate}'.")
                                
                                # Update the count for the matched registered plate
                                registered_plate_tracker_table.update_item(
                                    Key={'plate_number': plate},
                                    UpdateExpression="ADD seen_count :val SET last_seen_timestamp = :ts",
                                    ExpressionAttributeValues={
                                        ':val': 1,
                                        ':ts': plate_read_timestamp
                                    }
                                )
                                break
                        
                        if is_registered == False:
                            logger.info(f"PLATE NOT FOUND IN REGISTERED VEHICLES: Detected plate '{best_plate_number}'.")

                            # Get all plates from DynamoDB that happened in the previous ten minutes.
                            ten_minutes_in_ms = 10 * 60 * 1000
                            start_timestamp = plate_read_timestamp - ten_minutes_in_ms

                            # Query for the current day
                            query_response_today = lpr_table.query(
                                IndexName='DaysSinceEpochIndex',
                                KeyConditionExpression=Key('days_since_epoch').eq(days_since_epoch) & Key('plate_read_timestamp').between(start_timestamp, plate_read_timestamp)
                            )

                            # Query for the previous day in case the 10-minute window crosses midnight
                            previous_days_since_epoch = days_since_epoch - 1
                            query_response_yesterday = lpr_table.query(
                                IndexName='DaysSinceEpochIndex',
                                KeyConditionExpression=Key('days_since_epoch').eq(previous_days_since_epoch) & Key('plate_read_timestamp').between(start_timestamp, plate_read_timestamp)
                            )

                            recent_plates = query_response_today.get('Items', []) + query_response_yesterday.get('Items', [])
                            logger.info(f"Found {len(recent_plates)} recent plates for {best_plate_number} in the last 10 minutes.")

                            # Check if any of the recent plates were at the valet.
                            went_through_valet = False
                            for p in recent_plates:
                                lev_distance_result = levenshtein(p.get('best_plate_number'), best_plate_number)
                                if p.get('camera_label') == '900 Valet' and lev_distance_result <= 1:
                                    went_through_valet = True
                                    logger.info(f"MATCH FOUND: Unregistered plate '{best_plate_number}' was seen at '900 Valet'.")
                                    break
                            
                            if went_through_valet:
                                # If a plate went through valet and is_registered is FALSE, it should be generating revenue.
                                logger.info(f"Plate '{best_plate_number}' is generating revenue.")
                                
                                #Insert the plate into the valet_table with all of the information we have on it.
                                item = {
                                    'plate_read_id': plate_read_id,
                                    'best_plate_number': best_plate_number,
                                    'plate_read_timestamp': plate_read_timestamp,
                                    'best_confidence': best_confidence,
                                    'best_region': best_region,
                                    'days_since_epoch': getDaysSinceEpoch(),
                                    'plate_crop_jpeg_url': plate_crop_jpeg_url,
                                    'vehicle_crop_jpeg_url': vehicle_crop_jpeg_url,
                                    'revenue_received': 0
                                }

                                # Remove keys with None values before inserting into DynamoDB
                                item_to_insert = {k: v for k, v in item.items() if v is not None}

                                # Insert the plate into the valet table so we can track when it exits and how much money they owe.
                                valet_table.put_item(Item=item_to_insert)
                            else:
                                # If a plate did not go through valet and is_registered is FALSE, it should be sent to security.
                                logger.info(f"Plate '{best_plate_number}' NOT seen at valet. Sending to security.")

                    # Process the garage exits to figure out how much money revenue we should be getting.
                    if camera_label == '900 Garage Gate Exit':
                        logger.info("Plate seen exiting.")
                        
                        # Download all plates from the valet_table for the last 30 days where revenue has not been received.
                        current_day = getDaysSinceEpoch()
                        unpaid_plates = []
                        for i in range(30):
                            day_to_check = current_day - i
                            response = valet_table.query(
                                IndexName='DaysSinceEpochIndex',
                                KeyConditionExpression=Key('days_since_epoch').eq(day_to_check) & Key('revenue_received').eq(0)
                            )
                            unpaid_plates.extend(response.get('Items', []))
                        
                        logger.info(f"Found {len(unpaid_plates)} unpaid plates in the last 30 days.")

                        # Check if the exiting plate matches any of the unpaid plates.
                        matched_plate = None
                        for plate in unpaid_plates:
                            if clean_levenshtein(plate.get('best_plate_number'), best_plate_number) <= 1:
                                matched_plate = plate
                                break
                        
                        if matched_plate:
                            logger.info(f"MATCH FOUND: Exiting plate '{best_plate_number}' matches unpaid plate '{matched_plate.get('best_plate_number')}'.")
                            
                            # Calculate the time difference in hours.
                            entry_timestamp = matched_plate.get('plate_read_timestamp')
                            exit_timestamp = plate_read_timestamp
                            duration_ms = exit_timestamp - entry_timestamp
                            duration_hours = duration_ms / (1000 * 60 * 60)
                            
                            charge = 0
                            if duration_hours > 24:
                                charge = int(duration_hours / 24) * 36
                                duration_hours = duration_hours % 24

                            # Calculate the charge based on valet rates.
                            if duration_hours <= 2:
                                charge += 15
                            elif duration_hours <= 8:
                                charge += 20
                            elif duration_hours <= 12:
                                charge += 24
                            elif duration_hours <= 24:
                                charge += 36
                            
                            # Update the record in the valet_table.
                            valet_table.update_item(
                                Key={
                                    'plate_read_id': matched_plate.get('plate_read_id'),
                                    'plate_read_timestamp': matched_plate.get('plate_read_timestamp')
                                },
                                UpdateExpression="set revenue_received = :r",
                                ExpressionAttributeValues={
                                    ':r': int(charge)
                                },
                                ReturnValues="UPDATED_NEW"
                            )
                            logger.info(f"Charged ${charge} for {duration_hours:.2f} hours.")
                        else:
                            logger.info(f"No unpaid valet record found for exiting plate '{best_plate_number}'.")
                else:
                    logger.warning(f"No item found in DynamoDB for plate_read_id: {guid}")

        except json.JSONDecodeError as e:
            logger.error(f"Failed to decode JSON from SQS message body: {record['body']}. Error: {e}")
        except Exception as e:
            logger.error(f"An error occurred: {e}")
            # Depending on the error, you might want to re-raise it to have the message retried
            # For now, we log and continue to avoid blocking the queue for one bad message.
            pass

    return {
        'statusCode': 200,
        'body': json.dumps('Successfully processed verification messages.')
    }
